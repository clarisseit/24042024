

export default function DoctorListDash() {
  return (
    <div>DoctorListDash</div>
  )
}
