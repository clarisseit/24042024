

export default function PatientDash() {
  return (
    <div>PatientDash</div>
  )
}
