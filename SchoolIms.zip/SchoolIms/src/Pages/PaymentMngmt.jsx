import logo from "../assets/Group 1.png";
import paymentimg from "../assets/Frame 6.png";
import details from "../assets/details.png";

import { LuUsers } from "react-icons/lu";
import { AiOutlineMedicineBox } from "react-icons/ai";
import { MdManageHistory } from "react-icons/md";
import { AiOutlineInsurance } from "react-icons/ai";
import { HiOutlineDocumentReport } from "react-icons/hi";
import { AiOutlineDownload } from "react-icons/ai";
import { AiOutlineSearch } from "react-icons/ai";

import { CiSearch } from "react-icons/ci";
import { TbUrgent } from "react-icons/tb";
import { LiaGreaterThanSolid } from "react-icons/lia";
import { useState } from 'react';

import { FaRegCalendarAlt } from "react-icons/fa";
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { useEffect, useRef } from 'react';
import Chart from 'chart.js/auto';

const Dashboard = () => {
  const invoicePayments = [
    { studentName: 'Clarisse U.', paymentAmount: '₦10,000', studentClass: 'Creche', PaymentMethod: 'Online', status: 'Sucess ', date: 'April 04, 2024' },

    { studentName: 'Greg G  Clarisse', paymentAmount: '₦10,000', studentClass: 'Creche', PaymentMethod: 'Online', status: 'Sucess ', date: 'April 04, 2024' },

    { studentName: 'Clarisse U.', paymentAmount: '₦10,000', studentClass: 'Creche', PaymentMethod: 'Online', status: 'Sucess ', date: 'April 04, 2024' },
    { studentName: 'clarisse  Lance', paymentAmount: '₦10,000', studentClass: 'Creche', PaymentMethod: 'Online', status: 'Sucess ', date: 'April 04, 2024' },
    { studentName: 'Greg G  Uwizeyimana', paymentAmount: '₦10,000', studentClass: 'Creche', PaymentMethod: 'Online', status: 'Sucess ', date: 'April 04, 2024' },
    { studentName: 'Uwizeyimana  Lance', paymentAmount: '₦10,000', studentClass: 'Creche', PaymentMethod: 'Online', status: 'Sucess ', date: 'April 04, 2024' },
  ];


  const [userDetailsModalOpen, setUserDetailsModalOpen] = useState(false);
  const userDetails = {
    name: "Jonathan J Johnson",
    address: "Lane Ave, Josh Estate. Gbagada Lagos",
    dateOfBirth: "12/03/2022",
    gender: "Male",
    nationality: "Nigerian",
    grade: "Basic 1",
    outstandingBill: "₦100,280.00",
  };

  const handleUserButtonClick = () => {
    setUserDetailsModalOpen(true);
  };

  const handleCloseUserDetailsModal = () => {
    setUserDetailsModalOpen(false);
  };

  return (
    <div className="flex h-screen w-1/2">
      <aside className="bg-gray-900 text-white w-[30rem]">
        <div className="flex flex-col h-full">
          <div className="mb-8 gap-3 flex">
            <img src={logo} alt="Logo" className="w-[3rem] mt-[1rem] " />
            <p className="mt-[1rem]">PAYMENT HISTORY</p>
          </div>
          {/* Sidebar Navigation */}
          <nav className="">
            <ul>
              <li className="mb-4">
                <div className="rounded-lg h-full bg-slate-800 p-1 w-[15rem]">
                  <a href="#" className="text-black ml-[2rem] text-xl">Search</a>
                </div>
              </li>
              <li className="mb-4">
                <a href="#" className=" hover:text-green-300 flex gap-2 ml-8"> <b><LuUsers className="mt-[0.3rem]" /></b> Dashboard</a>
              </li>
              <li className="mb-4">
                <a href="paymentMngmnt" className=" hover:text-green-300 flex gap-2 ml-8"> <b><MdManageHistory className="mt-[0.3rem]" /></b>Payment management</a>
              </li>

              <li className="mb-4">
                <a href="#" className=" hover:text-green-300 flex gap-2 ml-8"> <AiOutlineMedicineBox className="mt-[0.3rem]" />Fee management</a>
              </li>
              <li className="mb-4">
                <a href="#" className=" hover:text-green-300 flex gap-2 ml-8"><b><AiOutlineInsurance className="mt-[0.3rem]" /></b>All students</a>
              </li>
              <li className="mb-4">
                <a href="#" className=" hover:text-green-300 flex gap-2 ml-8"><b><HiOutlineDocumentReport className="mt-[0.3rem]" /></b>Reporting and analytics </a>
              </li>
              <li className="mb-4">
                <a href="#" className=" hover:text-green-300 flex gap-2 ml-8"><b><HiOutlineDocumentReport className="mt-[0.3rem]" /></b>Communications </a>
              </li>
              <li className="mt-[14rem] bg-slate-300 ">
                <div className="rounded p-2">
                  <a href="#" className="text-black">Suport</a>
                </div>
              </li>
            </ul>
          </nav>
        </div>
      </aside >

      <main className="flex-1 p-10">
        <h2 className=" flex gap-3  text-gray-500"> <AiOutlineInsurance className="mt-[0.3rem]" />  Dashboard</h2>
        <div className="flex">
          <h6 className="text-2xl flex gap-2 mt-4">OverView</h6>
          <span className="flex mt-[1.4rem] ml-[38rem] gap-5">
            <button className="bg-blue-600 rounded-2xl w-[12rem]">Set up of payment</button>
            <AiOutlineInsurance className="mt-[0.3rem]" />
            <AiOutlineInsurance className="mt-[0.3rem]" />
            <AiOutlineInsurance className="mt-[0.3rem]" />
          </span>
        </div>
        <h2 className=" flex gap-3 mt-2 text-gray-500"> Your current account information and summary</h2>
        <div className="flex gap-[5rem] mt-4">
          <div className=" bg-white border border-gray-300  rounded-md px-4 py-2 focus:outline-none focus:ring-2">
            <div className="flex">
              <img src={paymentimg} alt="paymentimg" className="w-[3rem]" />
              <AiOutlineInsurance className=" ml-[12rem]" />
            </div>
            <h2 className=" flex gap-3 text-gray-500"> Total Fees Collected</h2>
            <div className="flex ">
              <h6 className="text-xl font-bold flex gap-2 mt-2">₦100,280.00</h6>
              <p className="flex ml-[5rem] mt-[.6rem] border-2 border-green-200 rounded-lg gap-2"><AiOutlineInsurance className=" mt-1" />10%</p>
            </div>
            <button>View report</button>
          </div>
          <div className=" bg-white border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2">
            <div className="flex">
              <img src={paymentimg} alt="paymentimg" className="w-[3rem]" />
              <AiOutlineInsurance className=" ml-[12rem]" />
            </div>
            <h2 className=" flex gap-3 text-gray-500"> Total Fees Collected</h2>
            <div className="flex ">
              <h6 className="text-xl font-bold flex gap-2 mt-2">₦100,280.00</h6>
              <p className="flex ml-[5rem] mt-[.6rem] border-2 border-green-200 rounded-lg gap-2"><AiOutlineInsurance className=" mt-1" />10%</p>
            </div>
            <button>View report</button>
          </div>
          <div className=" bg-white border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2">
            <div className="flex">
              <img src={paymentimg} alt="paymentimg" className="w-[3rem]" />
              <AiOutlineInsurance className=" ml-[12rem]" />
            </div>
            <h2 className=" flex gap-3 text-gray-500"> Total Fees Collected</h2>
            <div className="flex ">
              <h6 className="text-xl font-bold flex gap-2 mt-2">₦100,280.00</h6>
              <p className="flex ml-[5rem] mt-[.6rem] border-2 border-green-200 rounded-lg gap-2"><AiOutlineInsurance className=" mt-1" />10%</p>
            </div>
            <button>View report</button>
          </div>
        </div>
        <h6 className="text-2xl flex gap-2 mt-8">Recent Payments (04)<AiOutlineInsurance className="" /></h6>
        <div className="flex">

          <h2 className="  gap-3 mt-8 text-gray-500"> Lists of students who just made payment</h2>
          <span className="flex mt-[1.4rem] ml-[29rem] gap-5">
            <div className="relative -mt-[.rem] mr-2 border-2 w-[8rem] h-8">
              <textarea className="w-full h-full bg-transparent" />
              <AiOutlineSearch className="absolute top-1/2 transform -translate-y-1/2  left-2 text-blue-500 cursor-pointer hover:text-blue-700" />
            </div>



            <div className="flex border-2 px-[3rem] py-2"> <AiOutlineInsurance className=" -ml-10 absolute" /><p className=" w-2 h-2" >Filter</p></div>
          </span>
        </div>

        <div className="flex mt-6  ">
          <table className="table-auto border rounded-lg  ">
            <thead>
              <tr>

                <th className="py-2 px-4">Student Name</th>
                <th className="py-2 px-4"> Payment Amount</th>
                <th className="py-2 px-4">Student's Class</th>
                <th className="py-2 px-4">Payment method</th>
                <th className="py-2 px-4">Status</th>
                <th className="py-2 px-4">Date & Time</th>
              </tr>
            </thead>
            <tbody>
              {invoicePayments.map(payment => (
                <tr className="hover:bg-red-300" key={payment.invoice}>
                  <td className="py-2 px-4">{payment.studentName}</td>
                  <td className="py-2 px-4">{payment.paymentAmount}</td>
                  <td className="py-2 px-4">{payment.studentClass}</td>
                  <td className="py-2 px-4">{payment.PaymentMethod}</td>
                  <td className="py-2 px-4">{payment.status}</td>
                  <td className="py-2 px-4">{payment.date}</td>
                  <td className="py-2 px-4 flex text-blue-500 cursor-pointer hover:text-blue-700">
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <hr className="border-2 mt-6" />

        <div className="flex">

          <h2 className="  gap-3 mt-8 text-gray-500"> Paage 1 of 3</h2>
          <span className="flex mt-[1.4rem] ml-[43rem] gap-5">

            <div className="flex  gap-10"> <p className="border-2 cursor-pointer ">Privous </p><p className=" border-2 cursor-pointer " >Next</p></div>
          </span>
        </div>




      </main >
    </div >
  );
};






export default Dashboard;
