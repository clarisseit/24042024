

export default function PatientMngntDash() {
  return (
    <div>PatientMngntDash</div>
  )
}
