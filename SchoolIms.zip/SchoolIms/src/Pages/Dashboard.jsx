import logo from "../assets/Group 1.png";
import paymentimg from "../assets/Frame 6.png";
import details from "../assets/details.png";

import { LuUsers } from "react-icons/lu";
import { AiOutlineMedicineBox } from "react-icons/ai";
import { MdManageHistory } from "react-icons/md";
import { AiOutlineInsurance } from "react-icons/ai";
import { HiOutlineDocumentReport } from "react-icons/hi";
import { AiOutlineDownload } from "react-icons/ai";
import { AiOutlineSearch } from "react-icons/ai";

import { CiSearch } from "react-icons/ci";
import { TbUrgent } from "react-icons/tb";
import { LiaGreaterThanSolid } from "react-icons/lia";
import { useState } from 'react';

import { FaRegCalendarAlt } from "react-icons/fa";
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { useEffect, useRef } from 'react';
import Chart from 'chart.js/auto';

const Dashboard = () => {
  const invoicePayments = [
    { invoice: 'Invoice#2232', studentName: 'Clarisse .U', amount: 'N10,000', date: 'April 14, 2024', status: 'Pending' },
    { invoice: 'Invoice#2232', studentName: 'Clarisse .U', amount: 'N30,000', date: 'April 04, 2024', status: 'Pending' },
    { invoice: 'Invoice#2232', studentName: 'Themmy', amount: 'N104,000', date: 'April 12, 2024', status: 'Pending' },
    { invoice: 'Invoice#2232', studentName: 'Alice .U', amount: 'N610,000', date: 'April 21, 2024', status: 'Pending' },
    { invoice: 'Invoice#2232', studentName: 'Themmy .U', amount: 'N170,000', date: 'April 19, 2024', status: 'Pending' },
    { invoice: 'Invoice#2232', studentName: 'Clarisse .U', amount: 'N100,000', date: 'April 7, 2024', status: 'Pending' },
    { invoice: 'Invoice#2232', studentName: 'Clarisse .Themmy', amount: 'N110,000', date: 'April 13, 2024', status: 'Pending' },
    { invoice: 'Invoice#2232', studentName: ' Themmy Clarisse .U', amount: 'N105,000', date: 'April 20, 2024', status: 'Pending' },
  ];


  const [userDetailsModalOpen, setUserDetailsModalOpen] = useState(false);
  const userDetails = {
    name: "Jonathan J Johnson",
    address: "Lane Ave, Josh Estate. Gbagada Lagos",
    dateOfBirth: "12/03/2022",
    gender: "Male",
    nationality: "Nigerian",
    grade: "Basic 1",
    outstandingBill: "₦100,280.00",
  };

  const handleUserButtonClick = () => {
    setUserDetailsModalOpen(true);
  };

  const handleCloseUserDetailsModal = () => {
    setUserDetailsModalOpen(false);
  };

  return (
    <div className="flex h-screen w-1/2">
      <aside className="bg-gray-900 text-white w-[30rem]">
        <div className="flex flex-col h-full">
          <div className="mb-8 gap-3 flex">
            <img src={logo} alt="Logo" className="w-[3rem] mt-[1rem] " />
            <p className="mt-[1rem]">PAYMENT HISTORY</p>
          </div>
          {/* Sidebar Navigation */}
          <nav>
            <ul>
              <li className="mb-4">
                <div className="rounded-lg bg-slate-800 p-1 w-[15rem]">
                  <a href="#" className="text-black ml-[2rem] text-xl">Search</a>
                </div>
              </li>
              <li className="mb-4">
                <a href="#" className=" hover:text-green-300 flex gap-2 ml-8"> <b><LuUsers className="mt-[0.3rem]" /></b> Dashboard</a>
              </li>
              <li className="mb-4">
                <a href="paymentMngmnt" className=" hover:text-green-300 flex gap-2 ml-8"> <b><MdManageHistory className="mt-[0.3rem]" /></b>Payment management</a>
              </li>

              <li className="mb-4">
                <a href="#" className=" hover:text-green-300 flex gap-2 ml-8"> <AiOutlineMedicineBox className="mt-[0.3rem]" />Fee management</a>
              </li>
              <li className="mb-4">
                <a href="#" className=" hover:text-green-300 flex gap-2 ml-8"><b><AiOutlineInsurance className="mt-[0.3rem]" /></b>All students</a>
              </li>
              <li className="mb-4">
                <a href="#" className=" hover:text-green-300 flex gap-2 ml-8"><b><HiOutlineDocumentReport className="mt-[0.3rem]" /></b>Reporting and analytics </a>
              </li>
              <li className="mb-4">
                <a href="#" className=" hover:text-green-300 flex gap-2 ml-8"><b><HiOutlineDocumentReport className="mt-[0.3rem]" /></b>Communications </a>
              </li>
              <li className="mt-[14rem] bg-slate-300 ">
                <div className="rounded p-2">
                  <a href="#" className="text-black">Suport</a>
                </div>
              </li>
            </ul>
          </nav>
        </div>
      </aside >

      <main className="flex-1 p-10">
        <h2 className=" flex gap-3  text-gray-500"> <AiOutlineInsurance className="mt-[0.3rem]" />  Dashboard</h2>
        <div className="flex">
          <h6 className="text-2xl flex gap-2 mt-4">OverView</h6>
          <span className="flex mt-[1.4rem] ml-[38rem] gap-5">
            <button className="bg-blue-600 rounded-2xl w-[12rem]">Set up of payment</button>
            <AiOutlineInsurance className="mt-[0.3rem]" />
            <AiOutlineInsurance className="mt-[0.3rem]" />
            <AiOutlineInsurance className="mt-[0.3rem]" />
          </span>
        </div>
        <h2 className=" flex gap-3 mt-2 text-gray-500"> Your current account information and summary</h2>
        <div className="flex gap-[5rem] mt-4">
          <div className=" bg-white border border-gray-300  rounded-md px-4 py-2 focus:outline-none focus:ring-2">
            <div className="flex">
              <img src={paymentimg} alt="paymentimg" className="w-[3rem]" />
              <AiOutlineInsurance className=" ml-[12rem]" />
            </div>
            <h2 className=" flex gap-3 text-gray-500"> Total Fees Collected</h2>
            <div className="flex ">
              <h6 className="text-xl font-bold flex gap-2 mt-2">₦100,280.00</h6>
              <p className="flex ml-[5rem] mt-[.6rem] border-2 border-green-200 rounded-lg gap-2"><AiOutlineInsurance className=" mt-1" />10%</p>
            </div>
            <button>View report</button>
          </div>
          <div className=" bg-white border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2">
            <div className="flex">
              <img src={paymentimg} alt="paymentimg" className="w-[3rem]" />
              <AiOutlineInsurance className=" ml-[12rem]" />
            </div>
            <h2 className=" flex gap-3 text-gray-500"> Total Fees Collected</h2>
            <div className="flex ">
              <h6 className="text-xl font-bold flex gap-2 mt-2">₦100,280.00</h6>
              <p className="flex ml-[5rem] mt-[.6rem] border-2 border-green-200 rounded-lg gap-2"><AiOutlineInsurance className=" mt-1" />10%</p>
            </div>
            <button>View report</button>
          </div>
          <div className=" bg-white border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2">
            <div className="flex">
              <img src={paymentimg} alt="paymentimg" className="w-[3rem]" />
              <AiOutlineInsurance className=" ml-[12rem]" />
            </div>
            <h2 className=" flex gap-3 text-gray-500"> Total Fees Collected</h2>
            <div className="flex ">
              <h6 className="text-xl font-bold flex gap-2 mt-2">₦100,280.00</h6>
              <p className="flex ml-[5rem] mt-[.6rem] border-2 border-green-200 rounded-lg gap-2"><AiOutlineInsurance className=" mt-1" />10%</p>
            </div>
            <button>View report</button>
          </div>
        </div>
        <h6 className="text-2xl flex gap-2 mt-8">Recent Payments (04)<AiOutlineInsurance className="" /></h6>
        <div className="flex">

          <h2 className="  gap-3 mt-8 text-gray-500"> Lists of students who just made payment</h2>
          <span className="flex mt-[1.4rem] ml-[29rem] gap-5">
            <div className="relative -mt-[.rem] mr-2 border-2 w-[8rem] h-8">
              <textarea className="w-full h-full bg-transparent" />
              <AiOutlineSearch className="absolute top-1/2 transform -translate-y-1/2  left-2 text-blue-500 cursor-pointer hover:text-blue-700" />
            </div>



            <div className="flex border-2 px-[3rem] py-2"> <AiOutlineInsurance className=" -ml-10 absolute" /><p className=" w-2 h-2" >Filter</p></div>
          </span>
        </div>

        <div className="flex mt-6  ">
          <table className="table-auto">
            <thead>
              <tr>
                <th className="py-2 px-4">Invoice</th>
                <th className="py-2 px-4">Student Name</th>
                <th className="py-2 px-4">Amount</th>
                <th className="py-2 px-4">Date & Time</th>
                <th className="py-2 px-4">Status</th>
                <th className="py-2 px-4">Action</th>
              </tr>
            </thead>
            <tbody>
              {invoicePayments.map(payment => (
                <tr className="hover:bg-red-300" key={payment.invoice}>
                  <td className="py-2 px-4">{payment.invoice}</td>
                  <td className="py-2 px-4">{payment.studentName}</td>
                  <td className="py-2 px-4">{payment.amount}</td>
                  <td className="py-2 px-4">{payment.date}</td>
                  <td className="py-2 px-4">{payment.status}</td>
                  <td className="py-2 px-4 flex text-blue-500 cursor-pointer hover:text-blue-700">
                    <AiOutlineDownload className="text-blue-500 cursor-pointer hover:text-blue-700 mt-1" /> Download
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>


        <h6 className="text-2xl flex gap-2 mt-8">Upcoming Payments (45) <AiOutlineInsurance className="" /></h6>
        <div className="flex">

          <h2 className="  gap-3 mt-8 text-gray-500"> Expected payments (First term)</h2>
          <span className="flex mt-[1.4rem] ml-[43rem] gap-5">

            <div className="flex border-2 px-[3rem] py-2"> <AiOutlineInsurance className=" -ml-10 absolute" /><p className=" w-2 h-2" >Filter</p></div>
          </span>
        </div>

        <UserDetailsButton name={userDetails.name} userDetails={userDetails} onClick={handleUserButtonClick} />

        <UserDetailsModal isOpen={userDetailsModalOpen} onClose={handleCloseUserDetailsModal} userDetails={userDetails} />
        <div className="flex -mt-[2rem] ml-[11rem] flex-wrap gap-6 ">
          <div className=" border-2 rounded-lg bg-slate-50 border-gray-400  p-2 gap-6">
            Adejumo K Joyl</div>
          <div className=" border-2 rounded-lg bg-slate-50 border-gray-400  p-2 gap-6"> Blessing Faith</div>
          <div className=" border-2 rounded-lg bg-slate-50 border-gray-400  p-2 gap-6">Adogah L Faith</div>
          <div className=" border-2 rounded-lg bg-slate-50 border-gray-400  p-2 gap-6"> Alaba K Kolawole</div>
          <div className=" border-2 rounded-lg bg-slate-50 border-gray-400  p-2 gap-6">  Joy E  Favor</div>
          <div className=" border-2 rounded-lg bg-slate-50 border-gray-400  p-2 gap-6">Albert F Jeff</div>
          <div className=" border-2 rounded-lg bg-slate-50 border-gray-400  p-2 gap-6"> Howard Kull</div>
          <div className=" border-2 rounded-lg bg-slate-50 border-gray-400  p-2 gap-6">Alade J Semilore</div>
          <div className=" border-2 rounded-lg bg-slate-50 border-gray-400  p-2 gap-6">Oladipupo A Olawale</div>
          <div className=" border-2 rounded-lg bg-slate-50 border-gray-400  p-2 gap-6">Emily Lantern</div>
          <div> .........</div>
          <div> View All</div>
        </div>


      </main >
    </div >
  );
};

const UserDetailsModal = ({ isOpen, onClose, userDetails }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed z-10 inset-0 overflow-y-auto">
      <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div className="fixed inset-0 transition-opacity" aria-hidden="true">
          <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
        </div>
        <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
        <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
          <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
            <p className="bg-blue-500 rounded-lg w-[12rem]">Name: Jonathan J Johnson</p>
            <span className="flex gap-7 mt-4">

              <img src={details} alt="details" className="w-1/3 h-[10rem]" />
              <div className="mt-4 p-1">
                <p className="flex text-gray-500">Lane Ave, Josh Estate. Gbagada Lagos</p>
                <p> <b>Date of Birth</b> 12/03/2022</p>
                <p> <b>Gender</b> Male</p>
                <p ><b>Nationality</b> Nigerian</p>
                <p> <b>Grade</b> Basic 1</p>
                <p> <b>Outstanding Bill</b> ₦100,280.00</p></div>


            </span>
            <p className="text-gray-500">Outstanding Bill</p>
            <b>₦100,280.00</b>

          </div>

          <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
            <button
              onClick={onClose}
              type="button"
              className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-500 text-base font-medium text-white hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm">
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const UserDetailsButton = ({ name, userDetails, onClick }) => {
  return (
    <>
      <button
        onClick={onClick}
        className="mt-6 p-1 bg-slate-200 cursor-pointer border-2 border-blue-500 rounded-lg"
      >
        {name}
      </button>
    </>
  );
};



export default Dashboard;
