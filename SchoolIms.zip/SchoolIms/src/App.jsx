import { BrowserRouter, Routes, Route } from "react-router-dom";
import Dashboard from "./Pages/Dashboard";

import FeeMngnt from "./Pages/FeeMngnt";
import AllStudent from "./Pages/AllStudent";
import ReportAnalytics from "./Pages/ReportAnalytics";
import Communication from "./Pages/Communication";
import PaymentMngmt from "./Pages/PaymentMngmt";



export default function App() {
  return (

    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/paymentMngmnt" element={<PaymentMngmt />} />
        <Route path="/feeMngnt" element={<FeeMngnt />} />
        <Route path="/allStudent" element={<AllStudent />} />
        <Route path="/reportAnalytics" element={<ReportAnalytics />} />
        <Route path="/communication" element={<Communication />} />

      </Routes>
    </BrowserRouter>
  )
}
